package k23cnt2_nmt_day03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K23cnt2NmtDay03Application {

	public static void main(String[] args) {
		SpringApplication.run(K23cnt2NmtDay03Application.class, args);
	}

}
