package k23cnt2_nmt_day03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K23cnt2NmtDay03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
